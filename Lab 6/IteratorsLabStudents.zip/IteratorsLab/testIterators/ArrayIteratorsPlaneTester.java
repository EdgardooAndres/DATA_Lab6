package testIterators;

public class ArrayIteratorsPlaneTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a = {1, 2, 3, 4, 5, 5, 2, 4, 3}; 
		for (int x : a) { 
			System.out.println(x); 
		}

	}

}
