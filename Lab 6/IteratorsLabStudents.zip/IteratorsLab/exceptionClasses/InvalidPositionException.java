package exceptionClasses;

public class InvalidPositionException extends RuntimeException {

	public InvalidPositionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidPositionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidPositionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidPositionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
